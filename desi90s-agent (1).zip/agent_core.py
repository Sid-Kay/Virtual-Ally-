# agent_core.py
import asyncio, json, logging, os
from tools import ImageMocker, PaletteMaker, save_package
from memory import InMemorySession, MemoryBank
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)

class LLM:
    def __init__(self):
        self.api_key = os.getenv('OPENAI_API_KEY', '')
    async def generate(self, prompt: str, max_tokens: int=200) -> str:
        if not self.api_key:
            return "[SIMULATED LLM] " + (prompt[:400])
        return "[LLM output simulated for prompt:] " + prompt[:400]

class StyleAgent:
    def __init__(self, llm: LLM): self.llm = llm
    async def run(self, user_ctx):
        prompt = f"Create 3 outfit ideas with Desi + 90s romcom vibes for {user_ctx['occasion']}."
        out = await self.llm.generate(prompt)
        logger.info('StyleAgent done')
        return {'style_text': out}

class ArchAgent:
    def __init__(self, llm: LLM):
        self.llm = llm
        self.im = ImageMocker()
    async def run(self, user_ctx):
        prompt = f"Design 2 small spaces (mood descriptions) to match outfits for {user_ctx['occasion']}."
        out = await self.llm.generate(prompt)
        images = [self.im.create_mock_image('mood1'), self.im.create_mock_image('mood2')]
        logger.info('ArchAgent done')
        return {'arch_text': out, 'images': images}

class GameAgent:
    def __init__(self, llm: LLM): self.llm = llm
    async def run(self, user_ctx):
        prompt = "Make a 3-choice micro-game inspired by 90s romcoms."
        out = await self.llm.generate(prompt)
        logger.info('GameAgent done')
        return {'game_text': out}

class Coordinator:
    def __init__(self, llm: LLM, memory: InMemorySession):
        self.llm = llm; self.memory = memory
        self.style = StyleAgent(llm); self.arch = ArchAgent(llm); self.game = GameAgent(llm)

    async def build_package(self, user_ctx):
        session_id = user_ctx.get('session_id','default')
        self.memory.save(session_id, user_ctx)
        results = await asyncio.gather(
            self.style.run(user_ctx),
            self.arch.run(user_ctx),
            self.game.run(user_ctx)
        )
        merged = {**results[0], **results[1], **results[2]}
        caption_prompt = f"Write a 2-sentence caption combining: {merged.get('style_text','')[:200]} | {merged.get('arch_text','')[:200]}"
        caption = await self.llm.generate(caption_prompt)
        package = {'session_id': session_id, 'results': merged, 'caption': caption}
        save_package(package)
        logger.info('Package built')
        return package
