# run_local.py
import asyncio
from agent_core import LLM, InMemorySession, Coordinator

async def main():
    llm = LLM()
    mem = InMemorySession()
    coord = Coordinator(llm, mem)
    user_ctx = {
        'session_id': 'sid001',
        'occasion': 'backyard mehfil with friends',
        'likes': ['Desi aesthetic','90s romcoms','workout']
    }
    pkg = await coord.build_package(user_ctx)
    print('Package saved. Check outputs/package.json')

if __name__ == '__main__':
    asyncio.run(main())
