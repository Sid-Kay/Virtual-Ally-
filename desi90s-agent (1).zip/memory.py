# memory.py
import json, os

class InMemorySession:
    def __init__(self): self.store = {}
    def save(self, session_id, data): self.store[session_id] = data
    def load(self, session_id): return self.store.get(session_id, {})

class MemoryBank:
    def __init__(self, fname='memory.json'):
        self.fname = fname
        if not os.path.exists(fname):
            with open(fname,'w') as f: json.dump({}, f)
    def save_pref(self, user_id, prefs):
        with open(self.fname,'r') as f: data = json.load(f)
        data[user_id] = prefs
        with open(self.fname,'w') as f: json.dump(data, f, indent=2)
    def load_pref(self, user_id):
        with open(self.fname,'r') as f: data = json.load(f)
        return data.get(user_id, {})
