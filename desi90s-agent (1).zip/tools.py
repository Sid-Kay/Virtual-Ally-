# tools.py
import os, json
from datetime import datetime

class ImageMocker:
    def __init__(self, outdir='outputs'):
        self.outdir = outdir
        os.makedirs(outdir, exist_ok=True)
    def create_mock_image(self, name):
        fname = f"{self.outdir}/{name}_{int(datetime.now().timestamp())}.png"
        with open(fname, 'wb') as f:
            f.write(b'\x89PNG\r\n\x1a\n')
        return fname

class PaletteMaker:
    @staticmethod
    def from_text(text):
        return ['#C9564E', '#FFD27F', '#3D2C8D']

def save_package(pkg, out='outputs/package.json'):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out,'w') as f: json.dump(pkg, f, indent=2)
    return out
